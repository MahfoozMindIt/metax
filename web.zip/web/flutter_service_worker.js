'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"assets/AssetManifest.bin": "d595dded1958d459127bcde5a385ba6b",
"assets/AssetManifest.bin.json": "7b72ce616a1e83197c91c06b908cc34e",
"assets/AssetManifest.json": "e9b30ea7b7c4e8639299e1b21461c16b",
"assets/assets/images/accounts.png": "e49657567693df7fa67c89e5f31b7933",
"assets/assets/images/blue_baloon.png": "5a6fb57a5888a2b30dadf33a0aa53321",
"assets/assets/images/bottom_baloon.png": "fbd50c09f1f077c8549c2bc165e364d5",
"assets/assets/images/card.png": "4106cfcfc64d65a3720b53a64a734354",
"assets/assets/images/chart.png": "2b9176fd7f6fe1dd04e9b1702893ae9d",
"assets/assets/images/circles.png": "44b79c1c20d980450df3559858f90721",
"assets/assets/images/cropped_logo-white-bg.png": "d68c1e474ea69c1864f0b4995e85b830",
"assets/assets/images/cropped_logo.png": "2383096eac4b79823f793cbe45bde286",
"assets/assets/images/dollar.png": "37847440ecfa67e68ea081c777fd52ea",
"assets/assets/images/dummy-avatar.png": "8aac55c9ab90ff71a34603938664466c",
"assets/assets/images/favicon.png": "e3b5cea6e6db39d5f2e18c1aec3c1a68",
"assets/assets/images/gbp_flag.png": "952ad5fdfbc0d0b1aabb824401fff205",
"assets/assets/images/logo-small.png": "d7e4e9718ee11d0ec104f65f43573a00",
"assets/assets/images/logo.png": "130b4f68c2e070f85952f2a97610fb40",
"assets/assets/images/logo1.png": "0853adfd64dadbfc48fec4ba6b88acd4",
"assets/assets/images/logout.png": "aec7f0b1a099bf940a331bfaf43a5230",
"assets/assets/images/logo_up.png": "603b8f9dd6d1ec00a4bcb7af647b2059",
"assets/assets/images/logo_updated.png": "d9cf2e792c487fa007e8f898c2359b06",
"assets/assets/images/more.png": "a69fa21f8f325fbc931ea50776a64705",
"assets/assets/images/new_logo.png": "603b8f9dd6d1ec00a4bcb7af647b2059",
"assets/assets/images/pink_baloon.png": "11cfaabf4381d735f633c0252c2384fa",
"assets/assets/images/profile.png": "996f7eff5c63afd2d7ba2bc455210f18",
"assets/assets/images/purple_baloon.png": "abc85edf30df79ffdbd672976b530ea5",
"assets/assets/images/sepa.png": "399be7432a304fa1c4421bee5d0567d6",
"assets/assets/images/statements.png": "13a38c17fa09b5185b0b907b71a7f69f",
"assets/assets/images/swift.png": "9590ce895a2cc1883bb9d435c9415d98",
"assets/assets/images/transfer-purple.png": "6ce72c4fa2fcac598f256820f24712b7",
"assets/assets/images/transfer.png": "047cb6d050b6c11f6e68c56357c070c5",
"assets/assets/images/uk-faster.png": "336796795e6fcdcd8ab1f3bd83505a77",
"assets/assets/images/up_logo.png": "814ca9cd50bbdfc07c537da27c317e3f",
"assets/assets/images/usd_flag.png": "c5865a6e76af90d000368c07a246551b",
"assets/assets/images/users.png": "c9af267a4785b0f44ff3c05de8291831",
"assets/assets/images/Welcome.png": "f0a1299c8a0ca6029ddb088ec1dda779",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "9c22ffde2251c5ef1bb45ab022598dae",
"assets/NOTICES": "7c3be6554e279bb2deffc24ac8681ba6",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "e986ebe42ef785b27164c36a9abc7818",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"canvaskit/canvaskit.js": "738255d00768497e86aa4ca510cce1e1",
"canvaskit/canvaskit.js.symbols": "74a84c23f5ada42fe063514c587968c6",
"canvaskit/canvaskit.wasm": "9251bb81ae8464c4df3b072f84aa969b",
"canvaskit/chromium/canvaskit.js": "901bb9e28fac643b7da75ecfd3339f3f",
"canvaskit/chromium/canvaskit.js.symbols": "ee7e331f7f5bbf5ec937737542112372",
"canvaskit/chromium/canvaskit.wasm": "399e2344480862e2dfa26f12fa5891d7",
"canvaskit/skwasm.js": "5d4f9263ec93efeb022bb14a3881d240",
"canvaskit/skwasm.js.symbols": "c3c05bd50bdf59da8626bbe446ce65a3",
"canvaskit/skwasm.wasm": "4051bfc27ba29bf420d17aa0c3a98bce",
"canvaskit/skwasm.worker.js": "bfb704a6c714a75da9ef320991e88b03",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "383e55f7f3cce5be08fcf1f3881f585c",
"flutter_bootstrap.js": "9453088a4d2fbf4d96dbb5c3bef0c500",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "d01d1549cde6bfb28f55c89170eaa604",
"/": "d01d1549cde6bfb28f55c89170eaa604",
"main.dart.js": "28fb01df19297c389db4c7eac3693cc8",
"manifest.json": "0b97fc5af70f9468749b07581ce06ae4",
"version.json": "6e0958e9b09c7d6825b0fb1a1c82e71e"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
